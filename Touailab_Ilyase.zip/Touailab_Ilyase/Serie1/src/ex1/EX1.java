
package ex1;

import java.util.Scanner;

/**
 *
 * @author Touailab Ilyase
 */
public class EX1 {
    
    public static void main(String[] args) {
        
        Scanner s=new Scanner(System.in);
   
  
        System.out.println("Saisir le 1er nombre");
        double a=s.nextDouble();
        System.out.println("Saisir le 2eme nombre");
        double b=s.nextDouble();
        System.out.println("la division est : "+(a+b));
        if(b != 0){
            System.out.println("la division est : "+(a/b));
        }
        else
        {
            System.out.println("Erreur de division sur 0");
        }
        
        s.close();
        
        
        
        
    }
    
    
}
