
package ex4;

import java.util.Scanner;

/**
 *
 * @author Touailab Ilyase
 */
public class EX4 {
    
   
    public static void main(String[] args) {
        
        
         Scanner S=new Scanner(System.in);
            int n,i;
            
            n=i=0;
       
       
         while(i < 4)
        {
            System.out.print("Saisir le nombre ( "+i+" ) : ");
               n+=S.nextInt();
            
            i++;
        } 
             System.out.println("La somme est : "+n);
        
     
        
        S.close();
    }
    
}
