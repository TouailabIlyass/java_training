
package ex7;

import java.util.Scanner;

/**
 *
 * @author Touailab Ilyase
 */
public class EX7 {
    
    
   
    public static void main(String[] args) {
                Scanner s=new Scanner(System.in);
           double [] T =new double[5];

        for (int i = 0; i < T.length; i++) {
            
             System.out.print("T [ "+(i+1)+" ] :  ");
              T[i]=s.nextFloat();  
        }
         double min,max,my=0;
        min=max=T[0];
        for(int i=1;i<T.length;i++)
        {
            if(T[i] > max)
            {
                max=T[i];
            }
            else if(T[i] < min)
            {
                min=T[i];
            }
            my+=T[i];
            
        }
        
        System.out.println("moyenne :"+(my/T.length));
        System.out.println("max  :"+max);
        System.out.println("min  :"+min);
        
        s.close();
    }
    
}
