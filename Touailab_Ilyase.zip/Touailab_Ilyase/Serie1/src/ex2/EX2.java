
package ex2;

import java.util.Scanner;

/**
 *
 * @author Touailab Ilyase
 */
public class EX2 {
    
    
    
    public static void main(String[] args) {
        
        Scanner s=new Scanner(System.in);
    
       
     
       System.out.println("Saisir a :");
      double a=s.nextDouble();
       System.out.println("Saisir b :");
      double b=s.nextDouble();
       System.out.println("Saisir c :");
      double c=s.nextDouble();
      double delta=Math.pow(b,2)-(4*a*c);
       
       if(delta > 0)
       {
           System.out.println("-----Deux solutions x1 et x2-----"); 
           System.out.println("x1 = "+(-b-Math.sqrt(delta))/(2*a));
           System.out.println("x2 = "+(-b+Math.sqrt(delta))/(2*a));
       }
       else if(delta == 0)
       {
          System.out.println("-----une seule  solutions x1-----"); 
          System.out.println("x1 = "+(-b)/(2*a)); 
       }
       else
       {
           System.out.println("-----Pas de solutions !-----"); 
       }
       
       s.close();
    }
  
    
    
}
