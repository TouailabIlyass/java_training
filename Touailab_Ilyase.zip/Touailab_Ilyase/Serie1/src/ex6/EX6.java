
package ex6;

/**
 *
 * @author Touailab Ilyase
 */
public class EX6 {
    
     
    @Override
    public String toString()
    {
        return "redefinition|overriding du methode toString en cette class qui herite par defaut du class mere en java";
        
    }
    
    public static void main(String[] args) {
        
        EX6 obj=new EX6();
        System.out.println(obj.toString());
        
    }
}
