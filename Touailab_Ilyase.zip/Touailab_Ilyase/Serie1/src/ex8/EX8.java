
package ex8;

import java.util.Scanner;

/**
 *
 * @author Touailab Ilyase
 */
public class EX8 {
     
    public static void main(String[] args) {
         Scanner s=new Scanner(System.in);
        int [] T=new int[7];
        
        for(int i=0;i<T.length;i++)
        {
            System.out.print("Tab[ "+(i+1)+" ] : ");
            T[i]=s.nextInt();
            if(T[i]==1)
            {
                T[i]=0;
            } 
        }
        
        System.out.println("--------------------------");
        
        for(int i=0;i<T.length;i++)
        {
           System.out.print(T[i]+"-"); 
        }
        
      
        
        s.close();
    }
    
}
