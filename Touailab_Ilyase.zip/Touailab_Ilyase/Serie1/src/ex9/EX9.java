/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex9;

import java.util.Scanner;

/**
 *
 * @author Touailab Ilyase
 */
public class EX9 {
    
   
    public static void main(String[] args) {
         Scanner s=new Scanner(System.in);
       int [] T = {0,0,0,0,0,0};
        String str; 
       
        System.out.println("Saisir une mot : ");
        str=s.nextLine();
        str=str.toLowerCase();
        
        for(int i=0;i<str.length();i++)  //Anticonstitutionnellement
  
            switch(str.charAt(i))
            {
                case 'a': T[0]++; break;
                case 'e': T[1]++; break;
                case 'i': T[2]++; break;
                case 'o': T[3]++; break;
                case 'u': T[4]++; break;
                case 'y': T[5]++;                            
            }
                    
        
        
        System.out.println(T[0]+" Fois la lettre a");
        System.out.println(T[1]+" Fois la lettre e");
        System.out.println(T[2]+" Fois la lettre i");
        System.out.println(T[3]+" Fois la lettre o");
        System.out.println(T[4]+" Fois la lettre u");
        System.out.println(T[5]+" Fois la lettre y");
        
        s.close();
    }
}
