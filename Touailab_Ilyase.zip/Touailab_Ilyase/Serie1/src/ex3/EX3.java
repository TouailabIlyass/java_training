
package ex3;

import java.util.Scanner;

/**
 *
 * @author Touailab Ilyase
 */
public class EX3 {
    
    

    public static void main(String[] args) {
      Scanner s=new Scanner(System.in);
    
       
        System.out.print("Saisir le nombre :");
        int n=s.nextInt();
       int  fact=1;
        for(int i=2;i<=n;fact*=i,i++);
        
        System.out.println(n+" ! = "+fact);
        
        s.close();
    }
    
}
