
package ex5;

import java.util.Scanner;

/**
 *
 * @author Touailab Ilyase
 */
public class EX5 {
    
    
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);

        System.out.println("Saisir un nombre : ");
        int n=s.nextInt();
        double h=0;
        for(int i=1;i<=n;h+=1/(double)i,i++);
         System.out.println(" la serie harmo =   "+h);
         s.close();
        
    }
    
}
