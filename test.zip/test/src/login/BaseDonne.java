
package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;





public class BaseDonne {
    
    private static Connection connexion;
	
	public  BaseDonne()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/gestion_de_dossiers","root", "");
			System.out.println("connexion reussie!!");
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	private static  BaseDonne conn = new BaseDonne();
	
	public static Connection getConnexion() {
		return connexion;
	}


	public static BaseDonne getInstance()
	{
		return conn;
	}

   
}
