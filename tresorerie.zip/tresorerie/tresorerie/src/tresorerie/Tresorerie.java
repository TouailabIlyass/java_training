
package tresorerie;


public class Tresorerie {

    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
